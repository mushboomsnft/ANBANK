import { db } from "@db";
import * as schema from "@shared/schema";

// Export storage interface with any methods needed for CRUD operations
export const storage = {
  // Example method - not needed for the static landing page
  async getUser(username: string) {
    return db.query.users.findFirst({
      where: (users, { eq }) => eq(users.username, username)
    });
  }
};
