import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);
  
  return (
    <header className={`fixed w-full z-50 transition-colors duration-300 ${
      isScrolled ? "bg-black/80 backdrop-blur-md border-b border-gray-800" : "bg-transparent"
    }`}>
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/">
            <h1 className="text-2xl font-bold text-white cursor-pointer">
              <span className="text-primary">An</span>bank
            </h1>
          </Link>
        </div>
        
        <nav>
          <Button 
            asChild
            variant="default" 
            className="bg-primary hover:bg-[#2563EB] text-white font-medium transition-all duration-300 flex items-center gap-2"
          >
            <a 
              href="https://t.me/+w2HyLkZVStBjMzE0" 
              target="_blank" 
              rel="noopener noreferrer"
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-4 w-4" 
                viewBox="0 0 24 24" 
                fill="currentColor"
              >
                <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm-1.218 19l-1.782-5.218-4 2.5v-9.132l1.629 4.164 4.371-2.814 8 5.5-8.229 5zm-1.782-12.618l-0.833 3.75 0.833-0.564 5-3.196-5 0.01z"/>
              </svg>
              Telegram
            </a>
          </Button>
        </nav>
      </div>
    </header>
  );
}
