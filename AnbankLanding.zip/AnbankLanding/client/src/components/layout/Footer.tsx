import { Link } from "wouter";

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-[#000000] py-10 border-t border-gray-800">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <Link href="/">
              <h2 className="text-xl font-bold text-white cursor-pointer">
                <span className="text-primary">An</span>bank
              </h2>
            </Link>
            <p className="text-sm text-gray-500 mt-1">Your gateway to crypto & DeFi</p>
          </div>
          
          <div className="mb-6 md:mb-0">
            <a 
              href="https://t.me/+w2HyLkZVStBjMzE0" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-primary hover:text-white transition duration-300 inline-flex items-center"
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-5 w-5 mr-2" 
                viewBox="0 0 24 24" 
                fill="currentColor"
              >
                <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm-1.218 19l-1.782-5.218-4 2.5v-9.132l1.629 4.164 4.371-2.814 8 5.5-8.229 5zm-1.782-12.618l-0.833 3.75 0.833-0.564 5-3.196-5 0.01z"/>
              </svg>
              Telegram
            </a>
          </div>
          
          <div className="text-sm text-gray-500">
            &copy; {currentYear} Anbank. Все права защищены.
          </div>
        </div>
      </div>
    </footer>
  );
}
