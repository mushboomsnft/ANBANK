import { Button } from "@/components/ui/button";

export default function HeroSection() {
  return (
    <section className="crypto-bg pt-24 md:pt-32">
      <div className="gradient-bg bg-opacity-90 min-h-screen flex flex-col items-center justify-center px-4 py-20">
        {/* Main Hero Content */}
        <div className="container mx-auto text-center max-w-3xl">
          <div className="mb-8 inline-block">
            <div className="p-3 bg-primary/10 rounded-full inline-block animate-pulse">
              <div className="p-3 bg-primary/20 rounded-full">
                <div className="p-4 bg-primary rounded-full">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-8 w-8 text-white" 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      strokeWidth="2" 
                      d="M13 10V3L4 14h7v7l9-11h-7z" 
                    />
                  </svg>
                </div>
              </div>
            </div>
          </div>
          
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-white leading-tight">
            Anbank
          </h2>
          
          <p className="text-xl md:text-2xl mb-8 text-gray-300 max-w-2xl mx-auto">
            Мем-токен, который начался как шутка, но привлек реальных инвесторов 🚀
          </p>
          
          <div className="mb-12 flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              asChild
              variant="default"
              className="bg-primary hover:bg-[#2563EB] text-white font-medium text-lg py-6 px-8 h-auto rounded-xl transition-all duration-300 hover:shadow-lg hover:-translate-y-1"
            >
              <a 
                href="https://t.me/AnBankcommunity" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center"
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="h-5 w-5 mr-2" 
                  viewBox="0 0 24 24" 
                  fill="currentColor"
                >
                  <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm-1.218 19l-1.782-5.218-4 2.5v-9.132l1.629 4.164 4.371-2.814 8 5.5-8.229 5zm-1.782-12.618l-0.833 3.75 0.833-0.564 5-3.196-5 0.01z"/>
                </svg>
                Telegram
              </a>
            </Button>

            <Button 
              asChild
              variant="outline"
              className="text-white font-medium text-lg py-6 px-8 h-auto rounded-xl transition-all duration-300 hover:shadow-lg hover:-translate-y-1 border-gray-700 hover:bg-gray-800"
            >
              <a 
                href="https://x.com/BoomsMush" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center"
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 mr-2" 
                  viewBox="0 0 24 24"
                  fill="currentColor"
                >
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
                Twitter
              </a>
            </Button>
          </div>
          
          <div className="text-sm text-gray-400 max-w-lg mx-auto bg-black/40 backdrop-blur-sm py-4 px-6 rounded-lg">
            <p className="mb-0">Присоединяйтесь к нашему каналу сейчас, чтобы успеть приобрести токен первым!</p>
          </div>
        </div>
        
        {/* Waves separator */}
        <div className="w-full mt-16">
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            viewBox="0 0 1440 120" 
            className="text-black"
          >
            <path 
              fill="currentColor" 
              fillOpacity="1" 
              d="M0,96L48,85.3C96,75,192,53,288,48C384,43,480,53,576,69.3C672,85,768,107,864,101.3C960,96,1056,64,1152,58.7C1248,53,1344,75,1392,85.3L1440,96L1440,120L1392,120C1344,120,1248,120,1152,120C1056,120,960,120,864,120C768,120,672,120,576,120C480,120,384,120,288,120C192,120,96,120,48,120L0,120Z"
            ></path>
          </svg>
        </div>
      </div>
    </section>
  );
}
