import { useEffect, useState } from "react";
import { formatCountdownValue } from "@/lib/utils";

export default function ComingSoonSection() {
  const [countdownValues, setCountdownValues] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    // Target date: May 16, 2025
    const targetDate = new Date(2025, 4, 16); // Month is 0-indexed, so 4 = May
    
    const calculateTimeLeft = () => {
      const now = new Date();
      const difference = targetDate.getTime() - now.getTime();
      
      if (difference <= 0) {
        // If we've passed the target date
        return {
          days: 0,
          hours: 0,
          minutes: 0,
          seconds: 0
        };
      }
      
      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);
      
      return {
        days,
        hours,
        minutes,
        seconds
      };
    };
    
    // Initial calculation
    setCountdownValues(calculateTimeLeft());
    
    // Update every second
    const interval = setInterval(() => {
      setCountdownValues(calculateTimeLeft());
    }, 1000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="gradient-bg py-20">
      <div className="container mx-auto px-4 text-center">
        <div className="inline-block mb-8">
          <div className="relative">
            <div className="absolute inset-0 bg-primary blur-3xl opacity-20 rounded-full"></div>
            <div className="relative bg-black/80 backdrop-blur-sm p-6 border border-gray-800 rounded-xl">
              <h2 className="text-2xl font-bold text-white mb-4">Запуск 16 мая</h2>
              <p className="text-gray-400 mb-6">Первые покупатели получат мгновенную прибыль 5%, а затем наша ракета отправится к звездам!</p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-[#0F172A]/60 p-4 rounded-lg border border-primary/20 shadow-lg shadow-primary/10">
                  <div className="text-3xl md:text-4xl font-mono font-bold text-primary mb-1 transition-all">
                    {formatCountdownValue(countdownValues.days)}
                  </div>
                  <div className="text-xs uppercase tracking-wider text-gray-400">Дней</div>
                </div>
                <div className="bg-[#0F172A]/60 p-4 rounded-lg border border-primary/20 shadow-lg shadow-primary/10">
                  <div className="text-3xl md:text-4xl font-mono font-bold text-primary mb-1 transition-all">
                    {formatCountdownValue(countdownValues.hours)}
                  </div>
                  <div className="text-xs uppercase tracking-wider text-gray-400">Часов</div>
                </div>
                <div className="bg-[#0F172A]/60 p-4 rounded-lg border border-primary/20 shadow-lg shadow-primary/10">
                  <div className="text-3xl md:text-4xl font-mono font-bold text-primary mb-1 transition-all">
                    {formatCountdownValue(countdownValues.minutes)}
                  </div>
                  <div className="text-xs uppercase tracking-wider text-gray-400">Минут</div>
                </div>
                <div className="bg-[#0F172A]/60 p-4 rounded-lg border border-primary/20 shadow-lg shadow-primary/10">
                  <div className="text-3xl md:text-4xl font-mono font-bold text-primary mb-1 transition-all">
                    {formatCountdownValue(countdownValues.seconds)}
                  </div>
                  <div className="text-xs uppercase tracking-wider text-gray-400">Секунд</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <p className="text-gray-400 max-w-2xl mx-auto">
          Наш мем-токен стал серьезным проектом! Присоединяйтесь к нашему Телеграм каналу сейчас, чтобы успеть приобрести токен на ранней стадии.
        </p>
      </div>
    </section>
  );
}
