import { type Feature } from "@/lib/utils";

export default function FeaturesSection() {
  const features: Feature[] = [
    {
      icon: (
        <svg 
          xmlns="http://www.w3.org/2000/svg" 
          className="h-6 w-6 text-primary" 
          fill="none" 
          viewBox="0 0 24 24" 
          stroke="currentColor"
        >
          <path 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            strokeWidth="2" 
            d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" 
          />
        </svg>
      ),
      title: "Безопасность",
      description: "Ваши активы защищены передовыми протоколами безопасности",
    },
    {
      icon: (
        <svg 
          xmlns="http://www.w3.org/2000/svg" 
          className="h-6 w-6 text-primary" 
          fill="none" 
          viewBox="0 0 24 24" 
          stroke="currentColor"
        >
          <path 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            strokeWidth="2" 
            d="M9 5l7 7-7 7" 
          />
        </svg>
      ),
      title: "Простота",
      description: "Токен будет торговаться на сети Solana с интуитивным интерфейсом для всех пользователей",
    },
    {
      icon: (
        <svg 
          xmlns="http://www.w3.org/2000/svg" 
          className="h-6 w-6 text-primary" 
          fill="none" 
          viewBox="0 0 24 24" 
          stroke="currentColor"
        >
          <path 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            strokeWidth="2" 
            d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" 
          />
        </svg>
      ),
      title: "Доходность",
      description: "Ранние инвесторы получат 5% прибыли сразу после покупки. Дальнейший рост зависит от всего сообщества!",
    },
  ];

  return (
    <section className="bg-black py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4 text-white">
            История <span className="text-primary">An</span>bank
          </h2>
          <p className="text-lg text-gray-400 max-w-3xl mx-auto">
            Anbank начался как мем-токен и шутка, но благодаря активному сообществу привлек реальных инвесторов и рекламодателей. Сейчас это серьезный проект на блокчейне Solana, который будет существовать столько же, сколько будет жить сама сеть.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="feature-card p-6 rounded-xl border border-gray-800">
              <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2 text-white">{feature.title}</h3>
              <p className="text-gray-400">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-20 mb-20 p-6 bg-[#0F172A]/60 border border-primary/20 rounded-xl shadow-lg">
          <h3 className="text-2xl font-bold text-white mb-4 text-center">Стратегия роста</h3>
          <p className="text-gray-300 mb-4 text-lg">
            Как первый покупатель монеты, я обязуюсь не выводить свои средства и удерживать токены до тех пор, пока капитализация не достигнет 1 000 000. Только после этого будет снята часть средств исключительно на рекламу.
          </p>
          <p className="text-gray-300 text-lg">
            Все финансовые операции будут прозрачными и будут освещаться в реальном времени в нашем сообществе. Давайте вместе сделаем этот проект успешным!
          </p>
        </div>
        
        <div className="mt-16 text-center">
          <div className="inline-block bg-[#0F172A]/80 border border-gray-800 rounded-lg p-6 backdrop-blur-md">
            <div className="flex flex-col items-center justify-center gap-4">
              <span className="text-gray-300 text-lg mb-3">Присоединяйтесь к нам сейчас, чтобы успеть приобрести токен</span>
              <div className="flex flex-col sm:flex-row gap-3">
                <a 
                  href="https://t.me/AnBankcommunity" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="bg-primary hover:bg-[#2563EB] text-white py-2 px-6 rounded-lg transition duration-300 flex items-center justify-center"
                >
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-4 w-4 mr-2" 
                    viewBox="0 0 24 24" 
                    fill="currentColor"
                  >
                    <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm-1.218 19l-1.782-5.218-4 2.5v-9.132l1.629 4.164 4.371-2.814 8 5.5-8.229 5zm-1.782-12.618l-0.833 3.75 0.833-0.564 5-3.196-5 0.01z"/>
                  </svg>
                  Telegram
                </a>

                <a 
                  href="https://x.com/BoomsMush" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="bg-gray-800 hover:bg-gray-700 text-white py-2 px-6 rounded-lg transition duration-300 flex items-center justify-center border border-gray-700"
                >
                  <svg 
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 mr-2" 
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                  </svg>
                  Twitter
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
