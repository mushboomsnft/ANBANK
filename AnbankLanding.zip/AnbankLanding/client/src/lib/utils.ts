import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export type Feature = {
  icon: React.ReactNode;
  title: string;
  description: string;
};

export function formatCountdownValue(value: number): string {
  return value.toString().padStart(2, '0');
}
